﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

        let DataColor = "0xFFa9c4d6"
		let bg_img = "bg-1.png"
	    let step_img = "icon-batery.png"
		let hybryd_img = "icon-hybryd.png"
		let puls_img = "icon-puls.png"
		let batt_img = "icon-batery.png"
				
        let tap_dannye = 0;
        /* функция смены цветов массива данных */
            function click_dannye() {
            tap_dannye = (tap_dannye + 1) % 3;

        switch (tap_dannye) {
	
        case 0:
        /* кейс для первого цвета */
        DataColor = "0xFFa9c4d6"
		bg_img = "bg-1.png";
		step_img = "icon-step.png"
		hybryd_img = "icon-hybryd.png"
		puls_img = "icon-puls.png"
		batt_img = "icon-batery.png"
		h_array = ["Hour-0.png","Hour-1.png","Hour-2.png","Hour-3.png","Hour-4.png","Hour-5.png","Hour-6.png","Hour-7.png","Hour-8.png","Hour-9.png"];
        break;

        case 1:
        /* кейс для второго цвета */
        DataColor = "0xFFe27f65"
		bg_img = "bg-2.png";
		step_img = "icon-step2.png"
		hybryd_img = "icon-hybryd2.png"
		puls_img = "icon-puls2.png"
		batt_img = "icon-batery2.png"		
		h_array = ["Hour2-0.png","Hour2-1.png","Hour2-2.png","Hour2-3.png","Hour2-4.png","Hour2-5.png","Hour2-6.png","Hour2-7.png","Hour2-8.png","Hour2-9.png"];
        break;

         case 2:
        DataColor = "0xFF9e9a97"
		bg_img = "bg-3.png";
		step_img = "icon-step.png"
		hybryd_img = "icon-hybryd.png"
		puls_img = "icon-puls.png"
		batt_img = "icon-batery.png"		
		h_array = ["Hour3-0.png","Hour3-1.png","Hour3-2.png","Hour3-3.png","Hour3-4.png","Hour3-5.png","Hour3-6.png","Hour3-7.png","Hour3-8.png","Hour3-9.png"];	
         break;

        default:
        /* кейс для цвета по умолчанию/первого */	
        DataColor = "0xFFa9c4d6"
		bg_img = "bg-1.png";
		h_array = ["Hour-0.png","Hour-1.png","Hour-2.png","Hour-3.png","Hour-4.png","Hour-5.png","Hour-6.png","Hour-7.png","Hour-8.png","Hour-9.png"];		
}

            normal_background_bg_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: bg_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: batt_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_bio_charge_icon_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: hybryd_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: puls_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: step_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: 9,
              hour_startY: 139,
              hour_array: h_array,
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 254,
              minute_startY: 147,
              minute_array: ["Min-0.png","Min-1.png","Min-2.png","Min-3.png","Min-4.png","Min-5.png","Min-6.png","Min-7.png","Min-8.png","Min-9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 208,
              second_startY: 320,
              second_array: ["sec-0.png","sec-1.png","sec-2.png","sec-3.png","sec-4.png","sec-5.png","sec-6.png","sec-7.png","sec-8.png","sec-9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 240,
              center_y: 348,
              start_angle: 0,
              end_angle: 360,
              radius: 51,
              line_width: 7,
              corner_flag: 3,
              color: DataColor,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 240,
              center_y: 240,
              start_angle: 70,
              end_angle: 19,
              radius: 209,
              line_width: 53,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: DataColor,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.MORE, {
              center_x: 240,
              center_y: 240,
              start_angle: 161,
              end_angle: 109,
              radius: 209,
              line_width: 53,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: DataColor,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		}							
		
       let baro_num = 0
       let baro_all = 1
		function click_baro() {
		  baro_num = (baro_num + 1) % (baro_all + 1);
          if (baro_num == 0) {	
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, true);			  
	      normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, false);		  
    
          };
          if (baro_num == 1) {			  
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, true);	  
          };	  		  
		}		
		
       let stepdist_num = 0
       let stepdist_all = 1
		function click_stepdist() {
		  stepdist_num = (stepdist_num + 1) % (stepdist_all + 1);
          if (stepdist_num == 0) {	
		  normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_widget_text_5.setProperty(hmUI.prop.VISIBLE, true);			  
	      normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_6.setProperty(hmUI.prop.VISIBLE, false);		  
    
          };
          if (stepdist_num == 1) {			  
		  normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_widget_text_5.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_widget_text_6.setProperty(hmUI.prop.VISIBLE, true);	  
          };	  		  
		}		
		
       let battemp_num = 0
       let battemp_all = 1
		function click_battemp() {
		  battemp_num = (battemp_num + 1) % (battemp_all + 1);
          if (battemp_num == 0) {	
		  normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_widget_text_7.setProperty(hmUI.prop.VISIBLE, true);			  
	      normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_8.setProperty(hmUI.prop.VISIBLE, false);		  
    
          };
          if (battemp_num == 1) {			  
		  normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_widget_text_7.setProperty(hmUI.prop.VISIBLE, false);
		  normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_widget_text_8.setProperty(hmUI.prop.VISIBLE, true);	  
          };	  		  
		}				
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_body_temp_current_text_font = ''
        let normal_bio_charge_circle_scale = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_current_text_font = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_pressure_text_font = ''
        let normal_altimeter_current_text_font = ''
        let normal_floor_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_second_circle_scale = ''
        let normal_timerUpdateSec = undefined;
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_image_img = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРЕ', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_temperature_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_battery_current_text_font = ''
        let idle_bio_charge_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_step_current_text_font = ''
        let idle_altimeter_current_text_font = ''
        let idle_widget_text_1 = ''
        let idle_widget_text_2 = ''
        let idle_widget_text_4 = ''
        let idle_widget_text_5 = ''
        let idle_widget_text_7 = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРЕ', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let idle_system_disconnect_img = ''
        let idle_temperature_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: AldrichRUSbyDaymariusAsm.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 435,
              h: 43,
              text_size: 30,
              char_space: -2,
              line_space: 0,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 38
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 465,
              h: 48,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 400,
              h: 42,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 428,
              h: 43,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 41
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 496,
              h: 51,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: AldrichRUSbyDaymariusAsm.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 468,
              h: 45,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: AldrichRUSbyDaymariusAsm.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: -2,
              line_space: 0,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -70,
              // end_angle: -19,
              // radius: 235,
              // line_width: 53,
              // line_cap: Flat,
              // color: 0xFF464B4A,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -19,
              end_angle: -70,
              radius: 209,
              line_width: 53,
              corner_flag: 3,
              color: 0xFF464B4A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon-batery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 58,
              y: 117,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 64,
              y: 117,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 70,
              end_angle: 19,
              radius: 209,
              line_width: 53,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFFA9C4D6,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale.setAlpha(254);

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon-hybryd.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 310,
              y: 117,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 161,
              end_angle: 109,
              radius: 209,
              line_width: 53,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFFA9C4D6,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon-puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 310,
              y: 323,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 199,
              // end_angle: 250,
              // radius: 235,
              // line_width: 53,
              // line_cap: Flat,
              // color: 0xFF464B4A,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 250,
              end_angle: 199,
              radius: 209,
              line_width: 53,
              corner_flag: 3,
              color: 0xFF464B4A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon-step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 323,
              w: 131,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 323,
              w: 131,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 184,
              y: 106,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 184,
              y: 106,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'circle-sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 150,
              src: 'btOff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 348,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 54,
              // line_width: 7,
              // line_cap: Flat,
              // color: 0xFFA9C4D6,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 348,
              start_angle: 0,
              end_angle: 360,
              radius: 51,
              line_width: 7,
              corner_flag: 3,
              color: 0xFFA9C4D6,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 339,
              y: 74,
              w: 50,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'B',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 213,
              y: 72,
              w: 50,
              h: 50,
              text_size: 33,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'G',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 213,
              y: 72,
              w: 50,
              h: 50,
              text_size: 33,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'M',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 340,
              y: 361,
              w: 50,
              h: 50,
              text_size: 35,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 363,
              w: 50,
              h: 50,
              text_size: 41,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'S',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 363,
              w: 50,
              h: 50,
              text_size: 41,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'D',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 94,
              y: 74,
              w: 50,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'Z',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 94,
              y: 78,
              w: 50,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'T',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg-up1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 235,
              y: 421,
              w: 89,
              h: 50,
              text_size: 32,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 421,
              w: 108,
              h: 50,
              text_size: 32,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРЕ, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 184,
              y: 17,
              w: 111,
              h: 46,
              text_size: 32,
              char_space: -1,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 9,
              hour_startY: 139,
              hour_array: ["Hour-0.png","Hour-1.png","Hour-2.png","Hour-3.png","Hour-4.png","Hour-5.png","Hour-6.png","Hour-7.png","Hour-8.png","Hour-9.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 254,
              minute_startY: 147,
              minute_array: ["Min-0.png","Min-1.png","Min-2.png","Min-3.png","Min-4.png","Min-5.png","Min-6.png","Min-7.png","Min-8.png","Min-9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 208,
              second_startY: 320,
              second_array: ["sec-0.png","sec-1.png","sec-2.png","sec-3.png","sec-4.png","sec-5.png","sec-6.png","sec-7.png","sec-8.png","sec-9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 58,
              y: 117,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 310,
              y: 117,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 310,
              y: 323,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 323,
              w: 131,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 184,
              y: 106,
              w: 111,
              h: 46,
              text_size: 30,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 339,
              y: 74,
              w: 50,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'B',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 213,
              y: 72,
              w: 50,
              h: 50,
              text_size: 33,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'G',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 340,
              y: 361,
              w: 50,
              h: 50,
              text_size: 35,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 363,
              w: 50,
              h: 50,
              text_size: 41,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'S',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 94,
              y: 74,
              w: 50,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFA0A0A0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'Z',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 235,
              y: 421,
              w: 89,
              h: 50,
              text_size: 32,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 421,
              w: 108,
              h: 50,
              text_size: 32,
              char_space: -2,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРЕ, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 150,
              src: 'btOff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 184,
              y: 17,
              w: 111,
              h: 46,
              text_size: 32,
              char_space: -1,
              font: 'fonts/AldrichRUSbyDaymariusAsm.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 9,
              hour_startY: 143,
              hour_array: ["TimeAOD-0.png","TimeAOD-1.png","TimeAOD-2.png","TimeAOD-3.png","TimeAOD-4.png","TimeAOD-5.png","TimeAOD-6.png","TimeAOD-7.png","TimeAOD-8.png","TimeAOD-9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 250,
              minute_startY: 143,
              minute_array: ["TimeAOD-0.png","TimeAOD-1.png","TimeAOD-2.png","TimeAOD-3.png","TimeAOD-4.png","TimeAOD-5.png","TimeAOD-6.png","TimeAOD-7.png","TimeAOD-8.png","TimeAOD-9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 181,
              w: 150,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                 click_dannye();
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 0,
              w: 100,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 94,
              w: 100,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_baro();
vibro(23);
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 328,
              w: 83,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 328,
              w: 83,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_stepdist();
vibro(23);
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 89,
              w: 83,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_battemp();
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

        if (screenType != hmSetting.screen_type.AOD) {
	      normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, false);
	      normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_6.setProperty(hmUI.prop.VISIBLE, false);	
	      normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_8.setProperty(hmUI.prop.VISIBLE, false);	
		};		  
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Circle
              let normal_secondCircleProgress = 100 * second/60;
              if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Font
              let pressureValue = baroSensor.pressure;
              let normal_pressure_font = '-';
              if (pressureValue) normal_pressure_font = Math.round(pressureValue * 0.75006375541921).toString();
              normal_pressure_text_font.setProperty(hmUI.prop.TEXT, normal_pressure_font);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -19,
                      end_angle: -70,
                      radius: 209,
                      line_width: 53,
                      corner_flag: 3,
                      color: 0xFF464B4A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 250,
                      end_angle: 199,
                      radius: 209,
                      line_width: 53,
                      corner_flag: 3,
                      color: 0xFF464B4A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}