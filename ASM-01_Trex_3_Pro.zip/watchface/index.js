﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let normal_temperature_current_text = ''
        let normal_temperature_feel_text = ''
		let logo_img
		
        let zona1_num = 0
        let zona1_all = 1		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {
            normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);	
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_bio_charge_circle_scale.setProperty(hmUI.prop.VISIBLE, true);	
			normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          };
          if (zona1_num == 1) {	
            normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);	
            normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_bio_charge_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          };		  
		}	  

       let zona2_num = 0
       let zona2_all = 1
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {	 
		  normal_temperature_current_text.setProperty(hmUI.prop.VISIBLE, true);		  
	      normal_temperature_feel_text.setProperty(hmUI.prop.VISIBLE, false);	  
          };
          if (zona2_num == 1) {
	      normal_temperature_current_text.setProperty(hmUI.prop.VISIBLE, false);	  
	      normal_temperature_feel_text.setProperty(hmUI.prop.VISIBLE, true);	  
          };	  
		}		
		
       let zona3_num = 0
       let zona3_all = 1
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {	 
		  zona2_num.setProperty(hmUI.prop.VISIBLE, true);		  
  
          };
          if (zona3_num == 1) {
	      normal_temperature_current_text.setProperty(hmUI.prop.VISIBLE, false);	  
	  
          };	  
		}		
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_body_temp_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПОН', 'ВТР', 'СРЕ', 'ЧТВ', 'ПЯТ', 'СБТ', 'ВСК'];
        let normal_day_text_font = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_bio_charge_circle_scale = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПОН', 'ВТР', 'СРЕ', 'ЧТВ', 'ПЯТ', 'СБТ', 'ВСК'];
        let idle_day_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Rajdhani-Regular.ttf; FontSize: 60
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 692,
              h: 92,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BlackOpsOne-Regular.ttf; FontSize: 74
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1147,
              h: 128,
              text_size: 74,
              char_space: -3,
              line_space: 0,
              font: 'fonts/BlackOpsOne-Regular.ttf',
              color: 0xFF9D9D9D,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Rajdhani-Regular.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 582,
              h: 76,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BlackOpsOne-Regular.ttf; FontSize: 61
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 928,
              h: 106,
              text_size: 61,
              char_space: -3,
              line_space: 0,
              font: 'fonts/BlackOpsOne-Regular.ttf',
              color: 0xFF9D9D9D,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

// класс атм.давление // ---------------------------------------------------------------------------------------------------------------------------

	class AdvancedBarometer {
	  constructor(props = {}) {
		this.props = {
			unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,		// текущий индекс единицы измерения (сохраняется и считывается из памяти): 0 - мм рт.ст., 1 - гПа
			show_toast: true,											// показывать всплывающее сообщение при переключении единицы измерения
			widget: null,												// виджет TEXT для отображения давления
			show_trend: true,											// показывать тренд (растет, падает) после значения давления при обновлении виджета
			time_sensor: null,											// сенсор времени (для обновления давления), если не задан, то создается новый
			baro_sensor: null,											// сенсор давления, если не задан, то создается новый
			auto_update: true,											// автоматическое обновление давления (нет необходимости добавлять метод .update() в event.MINUTEEND и WIDGET_DELEGATE)
			d_time: 30,													// период времени (в мин), после которого происходит переинициализация опорного давления
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.unitStr = [	['мм рт.ст.',  'mmHg'],		// 0
							['гПа',  'hPa'],			// 1	
						]

		this.last = {
			value: null,
			trend: '',
		}

		this.prev = {
			value: null,
			time: 0,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.baro_sensor) this.props.baro_sensor = hmSensor.createSensor(hmSensor.id.BARO);
		if (isFinite(props.unit_index)) hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления давления
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// получить текущее значения  давления и тренда
		getPressureAndTrend(){
			const value = this.props.baro_sensor.pressure;
			//const value = randomInt(980, 1020)

			let trend = '';
			let pressureChange = 0;
			
			if (value && this.prev.value) pressureChange = value - this.prev.value;

			if (pressureChange < 0) trend = "↓";
			else if (pressureChange > 0) trend = "↑";

			return {value, trend}
		}

	// задать опорное показание давления и время его измерения
		set referenceValue(v) {
			this.prev.value = v;
			this.prev.time = Date.now();
		}

	// пришло время обновить опорное значение (если прошло времени больше, чем d_time)
		get needToUpdateReference() {
			return (Date.now() - this.prev.time > this.props.d_time * 1000 * 60)
		}

	// установить единицы измерения по индексу: 0 - мм рт.ст., 1 - гПа
		setUnits(unit_index) {
			if(!isFinite(unit_index)) return
			this.props.unit_index = unit_index == 1 ? 1 : 0;
			hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
			if (this.props.widget) this.updateWidget();
		}

	// переключить единицы измерения на следующие по кругу
		toggleUnits(show_toast = this.props.show_toast) {
			const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
			this.setUnits(newIndex);
			if (show_toast) hmUI.showToast({text: this.unit});
		}

	// обновить показания давления и виджет
		update() {
			const {value, trend}  = this.getPressureAndTrend();
			if (value != this.last.value){
				this.last.value = value;
				this.last.trend = trend;
				if (this.props.widget) this.updateWidget();
			}
			
			// обновляем опорное значение, если вышло время
			if (this.needToUpdateReference) this.referenceValue = value;
		}

	// обновить виджет
		updateWidget() {
			let str = this.pressure;
			if (this.props.show_trend) str += ` ${this.last.trend}`;
			this.props.widget.setProperty(hmUI.prop.TEXT, str);
		}

	// получить текущее значение давление в мм рт. ст.
		get mmHg() {
			let v = this.last.value;
			if (!(v)) return '--'
			else v *= 0.750064;
			return Math.round(v).toString();
		}

	// получить текущее значение давление в гПа
get hPa() {
	let v = this.last.value;
	if (!(v)) return '--'
	return Math.round(v).toString();
}

	// получить давление в текущих единицах измерения
		get pressure() {
			if (this.props.unit_index == 0) return this.mmHg
			else return this.hPa
		}

	// получить название текущей единицы измерения
		get unit() {
			return this.unitStr[this.props.unit_index][this.props.lang]
		}

	// получить индекс текущей единицы измерения
		get unit_index() {
			return this.props.unit_index
		}

	// получить тренд
		get trend() {
			return this.last.trend
		}

	// удалить
	  delete() {
		this.props = null;
		this.last = null;
		this.unitStr = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}
	
	
	// экземпляр класса погодный провайдер// --------------------------------------------------------------------------------------------------------------------------
	
	class WeatherProvider {
	  constructor(props = {}) {
		this.props = {
			night_icons: [],											// индексы иконок для замены день-ночь
			index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
			show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
			temp_widget: null,											// виджет TEXT для отображения температуры
			temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
			temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
			temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
			description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
			cityName_widget: null,										// виджет TEXT для отображения названия города
			icon_widget: null,											// виджет IMG для отображения значка погоды
			time_sensor: null,											// сенсор времени, если не задан, то создается новый
			weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
			file_name: 'weather.json',									// имя файла с погодными данными
			auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.providers = [
						{name: ['Zepp', 'Zepp'], appId: null},							// 0
						{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
						{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
					]

		this.description = [
				['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
				['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
			]

		this.last = {
			weatherIcon: 25,
			weatherDescription:  'Нет данных',
			temperature: '--',
			temperatureFeels: '--',
			temperatureMax: '--',
			temperatureMin: '--',
			cityName: '--',
			modTime: null,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
		if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления погоды
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// служебные функции
		arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
			  result += String.fromCharCode(byte1);
			} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result
		}

	// чтение погодных данных из файла
		readFile(app_id) {
		  if (!app_id) return null				
		  let str_result = "";
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			if (err == 0) {
			  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
				appid: app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = this.arrayBufferToCyrillic(array_buffer);

			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return null;
		}

	// получить время последнего изменеия файла
		getFileModTime(app_id) {
		  if (!app_id) return null
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			
			if (err == 0) {
			  return fs_stat.mtime
			} else {
			  console.log("ModTime err:", err);
			}
		  } catch (error) {
			console.log("ModTime error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
			return null
		}

	// проверка времени суток: возвращает true, если сейчас день
		isDayNow() {
			const sunData = this.props.weather_sensor.getForecastWeather().tideData;
			let sunriseMins = 8 * 60;			// время восхода
			let sunsetMins = 20 * 60;			// и заката по умолчанию

			if (sunData.count > 0){
				const today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			}

			const curMins = curTime.hour * 60 + curTime.minute;
			const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

			return nowIsDay
		}


	// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
		getZeppIconIndex(index, app_id = null) {
			
			if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

			let newIndex = 25;
			
			if (app_id == 1065824) {					// WeatherService
				switch(index) {
				   case 1:
						newIndex = 3;
					break;
				   case 2:
						newIndex = 0;
					break;
				   case 3:
				   case 4:
						newIndex = 4;
					break;
				   case 5:
						newIndex = 1;
					break;
				   case 6:
						newIndex = 5;
					break;
				   case 7:
						newIndex = 10;
					break;
				   case 8:
						newIndex = 15;
					break;
				   case 9:
						newIndex = 6;
					break;
				   case 10:
						newIndex = 8;
					break;
				   case 11:
						newIndex = 9;
					break;
				   case 12:
						newIndex = 12;
					break;
				   case 13:
						newIndex = 13;
					break;
				   case 14:
						newIndex = 17;
					break;
				   default:
						newIndex = 25;
					break;
				}
			} else if (app_id == 1066654) {					// RuWeather
				newIndex = index - 1;
			}

			return newIndex
		}

	// температура со знаком
		tempWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			// if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}

	//получение погодных данных из Zepp
		getZeppWeatherData() {
			const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
			const data = {
				weatherIcon: iconIndex,
				weatherDescription:  this.description[this.props.lang][iconIndex],
				temperature: this.props.weather_sensor.current ?? '--',
				temperatureFeels: '--',
				temperatureMax: this.props.weather_sensor.high ?? '--',
				temperatureMin: this.props.weather_sensor.low ?? '--',
				cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
			}

			return data
		}

	//получение погодных данных из файла приложения
		getAppWeatherData(app_id) {
			const data = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
			}

			// читаем данные из файла данных приложения
			let weather_str = this.readFile(app_id);
			let weatherJson = JSON.parse(weather_str);
	  
			if (weatherJson) {
				if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
				  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
				}

				if (weatherJson?.weatherDescriptionExtended?.length) {
				  data.weatherDescription = weatherJson.weatherDescriptionExtended;
				  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
				} else data.weatherDescription = this.description[data.weatherIcon];

				if (isFinite(weatherJson.temperature)) {
				  data.temperature = parseFloat(weatherJson.temperature);
				  data.temperature = Math.round(data.temperature);
				}
				
				if (isFinite(weatherJson.temperatureFeels)){
					data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
					data.temperatureFeels = Math.round(data.temperatureFeels);
				}
				  
				if (isFinite(weatherJson.temperatureMax)){
					data.temperatureMax = parseFloat(weatherJson.temperatureMax);
					data.temperatureMax = Math.round(data.temperatureMax);
				}
				  
				if (isFinite(weatherJson.temperatureMin)){
					data.temperatureMin = parseFloat(weatherJson.temperatureMin);
					data.temperatureMin = Math.round(data.temperatureMin);
				}
				
				if (weatherJson.city) {
				  data.cityName = weatherJson.city;
				}
			}
			
			return data
		}

	//получение погодных данных из файла приложения или Zepp
		getWeatherData(app_id = null) {
			if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
			else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
		}

	// обновить виджеты, используя данные текущего провайдера
		update() {
			let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

			const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
			
			if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
				const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
				this.last.modTime = modTime;

				let val = this.tempWithSign(newData.temperature);
				if (val != this.last.temperature){
					this.last.temperature = val;
					if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureMax);
				if (val != this.last.temperatureMax){
					this.last.temperatureMax = val;
					if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureMin);
				if (val != this.last.temperatureMin){
					this.last.temperatureMin = val;
					if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureFeels);
				if (val != this.last.temperatureFeels){
					this.last.temperatureFeels = val;
					if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.cityName;
				if (val != this.last.cityName){
					this.last.cityName = val;
					if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.weatherDescription;
				if (val != this.last.weatherDescription){
					this.last.weatherDescription = val;
					if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
				}

				
				curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
			}

			if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
				curIcon += 'n';
			}

			if (curIcon != this.last.weatherIcon){
				this.last.weatherIcon = curIcon;
				if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
			}
		}

	// переключить на следующего провайдера
		next(show_toast = this.props.show_toast) {
			const v = (this.props.index + 1) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить на предыдующего провайдера
		prev(show_toast = this.props.show_toast) {
			const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить назад или вперед
		toggle(dir, show_toast = this.props.show_toast) {
			if (dir > 0) this.next(show_toast)
			else this.prev(show_toast);
		}
		
	// установить провайдера по индексу
		set provider(v) {
			this.props.index = v;
			hmFS.SysProSetInt('WeatherProviderIndex', v);
			this.update();
		}

	// получить индекс текущего провайдера
		get index() {
			return this.props.index
		}

	// получить название текущего провайдера
		get name() {
			return this.providers[this.props.index].name[this.props.lang]
		}

	// получить название города
		get cityName() {
			return this.last.cityName
		}

	// получить текущую температуру
		get temperature() {
			return this.last.temperature
		}

	// получить максимальную температуру
		get temperatureMax() {
			return this.last.temperatureMax
		}

	// получить минимальную температуру
		get temperatureMin() {
			return this.last.temperatureMin
		}

	// получить ощущаемую температуру
		get temperatureFeels() {
			return this.last.temperatureFeels
		}

	// получить описание погоды
		get weatherDescription() {
			return this.last.weatherDescription
		}

	// удалить
	  delete() {
		this.providers = null;
		this.props = null;
		this.last = null;
		this.description = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}	
	
	
	
// служебные константы
const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT, screenShape: isRoundScreen } = hmSetting.getDeviceInfo();
	
	/********  класс всплывающее сообщение с таймаутом и расширенными настройками *********/
class Message {      
  #msg = null													// само сообщение
  
  constructor(props = {}) {
	this._propsDef = {											// параметры по умолчанию
		y: isRoundScreen ? 60 : 30,								// отступ рамки от верхней границы экрана для круглых и прямоугольных экранов
		offset: 10,												// отступ текста от рамки
		w: null,												// ширина рамки	(null - автовычисление размеров)
		h: null,												// высота рамки	(null - автовычисление размеров)
		text: '',
		text_size: 30,											// размер текста
		color: 0x666666,										// цвет рамки
		text_color: 0xffffff,									// цвет текста
		alpha: 250,												// прозрачность рамки
		radius: 25,												// радиус скругления рамки
		timeout: 1500,											// время показа сообщения, если равно 0 - не прятать
		...props
	};
	this._timer = null;
	this._visible = false;
  }

  delete() {
	this.visible = false;
	hmUI.deleteWidget(this.#msg);
	this.#msg = null;
	this._props = null;
	if (this._timer) {
		clearTimeout(this._timer);
		this._timer = null
	}
  }

  show(props = {}) {
	this._props = {...this._propsDef, ...props}
	if (!this._props.w) this._props.auto_w = true
	if (!this._props.h) this._props.auto_h = true
	if (this._visible) this.#update()
	else this.#create();
  }

  hide() {
	if (this._visible) this.#moveOut();
  }

  #create() {
	const {propsGroup, propsFrame, propsText} = this.#getWidgetProps();
	if (this._timer) clearTimeout(this._timer);
	this._timer = null;
	this._visible = true;
	const root = this;

	this.#msg = hmUI.createWidget(hmUI.widget.GROUP, propsGroup);

	this._frame = this.#msg.createWidget(hmUI.widget.FILL_RECT, propsFrame);
	this._frame.addEventListener(hmUI.event.CLICK_DOWN, function () {
		root.#moveOut();
	});

	this._text = this.#msg.createWidget(hmUI.widget.TEXT, propsText);
	this._text.setEnable(false);

	if (this._props.timeout) {
		this._timer = setTimeout(() => {
			this.#moveOut();
		}, this._props.timeout)
	}

	this.#moveIn();
  }

  #update() {
	const {propsGroup, propsFrame, propsText} = this.#getWidgetProps();
	if (this._timer) clearTimeout(this._timer);
	this._timer = null;
	propsGroup.y = this._props.y;
	this.#msg.setProperty(hmUI.prop.MORE, propsGroup);
	this._frame.setProperty(hmUI.prop.MORE, propsFrame);
	this._text.setProperty(hmUI.prop.MORE, propsText);

	if (this._props.timeout) {
		this._timer = setTimeout(() => {
			this.#moveOut();
		}, this._props.timeout)
	}
  }

  #getWidgetProps() {
	const { width, height } = this.#calcSize(this._props.text , this._props.text_size);
	if (this._props.auto_w) this._props.w = width;
	if (this._props.auto_h) this._props.h = height;
	if (height == DEVICE_HEIGHT - this._props.y) this._props.align_v = hmUI.align.TOP;

	const propsGroup =  {
		x: (DEVICE_WIDTH - this._props.w) / 2,
		y: - this._props.h,
		w: this._props.w,
		h: this._props.h,
	}

	const propsFrame = {
		x: 0,
		y: 0,
		w: this._props.w,
		h: this._props.h,
		color: this._props.color,
		radius: this._props.radius,
		alpha: this._props.alpha
	}

	const propsText = {
		x: this._props.offset,
		y: this._props.offset,
		w: this._props.w - 2 * this._props.offset,
		h: this._props.h - 2 * this._props.offset,
		text_size: this._props.text_size || 30,
		char_space: this._props.char_space || 0,
		line_space: this._props.line_space || 0,
		text: this._props.text,
		color: this._props.text_color,
		align_h: this._props.align_h || hmUI.align.CENTER_H,
		align_v: this._props.align_v || hmUI.align.CENTER_V,
		text_style: this._props.text_style || hmUI.text_style.WRAP,
	}
	
	if (this._props.font) propsText.font = this._props.font;
	return {propsGroup, propsFrame, propsText}
  }


  #calcSize(txt, size) {
	const maxW = DEVICE_WIDTH - (isRoundScreen ? 150 : 60);								// максимальная ширина
	let { width, height } = hmUI.getTextLayout(txt, {
		text_size: size,
		text_width: maxW - 2 * this._props.offset,
	});
	width += 2 * this._props.offset;
	height += 2 * this._props.offset;
	if (height > DEVICE_HEIGHT - this._props.y) height = DEVICE_HEIGHT - this._props.y;
	return {width, height}
  }

  #moveIn() {
	const moveAnim = {
		anim_steps: [{
		  anim_rate: 'easeout',
		  anim_duration: 350,
		  anim_from: -this._props.h,
		  anim_to: this._props.y,
		  anim_prop: hmUI.prop.Y,
		}],
		anim_fps: 25,
		anim_auto_start: 1,
		anim_repeat: 0,
		anim_auto_destroy: 1,
	}			  
	
	this._visible = true;			  
	this.#msg.setProperty(hmUI.prop.ANIM, moveAnim);
  }

  #moveOut() {
	const moveAnim = {
		anim_steps: [{
		  anim_rate: 'easein',
		  anim_duration: 550,
		  anim_from: this._props.y,
		  anim_to: -this._props.h,
		  anim_prop: hmUI.prop.Y,
		}],
		anim_fps: 25,
		anim_auto_start: 1,
		anim_repeat: 0,
		anim_auto_destroy: 1,
		anim_complete_func:() => {
			this.delete();
		}
	}			  
	if (this._timer) {
		clearTimeout(this._timer);
		this._timer = null;
	}
	this.#msg.setProperty(hmUI.prop.ANIM, moveAnim);
  }

  set visible(v) {
	this._visible = v;
	if(this.#msg) this.#msg.setProperty(hmUI.prop.VISIBLE, v);
  }
  
  get visible() {
	return this._visible
  }
  
  set y(v) {
	this._propsDef.y = v;
	if (this._visible) {
		this._props.y = v;
		this.#update();
	}
  }

  set text(txt) {
	if (this._text){
		this._text.setProperty(hmUI.prop.TEXT, txt);
		if (this._timer) {
			clearTimeout(this._timer);
			this._timer = setTimeout(() => {
				this.#moveOut();
			}, this._props.timeout)
		}
	}
  }

  set color(v) {
	this._propsDef.color = v;
	if (this._frame) {
		this._props.color = v;
		this._frame.setProperty(hmUI.prop.MORE, {
			x: 0,
			y: 0,
			w: this._props.w,
			h: this._props.h,
			color: this._props.color,
			radius: this._props.radius,
			alpha: this._props.alpha
		});
	}
  }

  set text_color(v) {
	this._propsDef.text_color = v;
	if (this._text) {
		this._props.text_color = v;
		this._text.setProperty(hmUI.prop.MORE, { color: v});
	}
  }
  
  set timeout(v) {
	this._propsDef.timeout = v;
	if (this._timer) {
		clearTimeout(this._timer);
		this._timer = setTimeout(() => {
			this.#moveOut();
		}, v);
	}
  }
}
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            logo_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 340,
              src: 'logo_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		    normal_temperature_current_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 192,
              y: 384,
              w: 103,
              h: 60,
              text_size: 64,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
            });	
						

            normal_temperature_feel_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 192,
              y: 384,
              w: 103,
              h: 60,
              text_size: 64,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFb9e36f,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
            });
						
			
        // экземпляр класса погодный провайдер		
            const weatherProvider = new WeatherProvider({
	            show_toast: true,
	            auto_update: true,			
	            temp_widget: normal_temperature_current_text, 
                temp_feels_widget: normal_temperature_feel_text,			
            });		
            logo_img.setProperty(hmUI.prop.SRC, `logo_${weatherProvider.index}.png`);			
            // end user_script.js

            normal_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 164,
              y: 374,
              w: 153,
              h: 60,
              text_size: 60,
              char_space: 0,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 164,
              y: 374,
              w: 153,
              h: 60,
              text_size: 60,
              char_space: 0,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 181,
              y: 94,
              w: 118,
              h: 60,
              text_size: 48,
              char_space: 1,
              color: 0xFFB4B4B4,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПОН, ВТР, СРЕ, ЧТВ, ПЯТ, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 192,
              y: 24,
              w: 100,
              h: 70,
              text_size: 74,
              char_space: -3,
              font: 'fonts/BlackOpsOne-Regular.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 360,
              center_y: 239,
              start_angle: -150,
              end_angle: 150,
              radius: 71,
              line_width: 10,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFF808000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 162,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 298,
              y: 204,
              w: 124,
              h: 60,
              text_size: 60,
              char_space: 0,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 120,
              // center_y: 238,
              // start_angle: -150,
              // end_angle: 150,
              // radius: 75,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF808000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 120,
              center_y: 238,
              start_angle: -150,
              end_angle: 150,
              radius: 70,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF808000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 58,
              y: 211,
              w: 124,
              h: 50,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 120,
              center_y: 239,
              start_angle: -150,
              end_angle: 150,
              radius: 71,
              line_width: 10,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFF808000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 42,
              y: 162,
              src: 'icon_bio.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 60,
              y: 204,
              w: 124,
              h: 60,
              text_size: 60,
              char_space: 0,
              font: 'fonts/Rajdhani-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secunde_2.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 181,
              y: 92,
              w: 118,
              h: 60,
              text_size: 48,
              char_space: 1,
              color: 0xFFB4B4B4,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПОН, ВТР, СРЕ, ЧТВ, ПЯТ, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 192,
              y: 308,
              w: 100,
              h: 70,
              text_size: 61,
              char_space: -3,
              font: 'fonts/BlackOpsOne-Regular.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

const msg = new Message();
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 56,
              y: 219,
              w: 128,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 340,
              w: 94,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                weatherProvider.next();
logo_img.setProperty(hmUI.prop.SRC, `logo_${weatherProvider.index}.png`);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 386,
              w: 94,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                msg.show({text: 'Макс. :   ' + weatherProvider.temperatureMax  + '\nМин. :   ' + weatherProvider.temperatureMin + '\n' + weatherProvider.weatherDescription , text_size: 36, timeout: 5000})

              }, // end func
              longpress_func: (button_widget) => {
                click_zona2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 353,
              w: 94,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (screenType != hmSetting.screen_type.AOD) {
            normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);	
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
	        normal_temperature_feel_text.setProperty(hmUI.prop.VISIBLE, false);			
            };
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 120,
                      center_y: 238,
                      start_angle: -150,
                      end_angle: 150,
                      radius: 70,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF808000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}